hamming-village
